FrostTuneX Auto Creator AI — Manish (Free Starter)

HOW TO RUN
1. Extract this ZIP.
2. Open index.html in a modern browser.
3. Use the 🚀 Auto Creator tab to generate a template-based multi-platform content pack, design and download a thumbnail PNG, and create/export a posting queue CSV.
4. Content/customer/queue data is stored locally in this browser only. Use backup/export regularly.

IMPORTANT LIMITATIONS
- This is a free, browser-only starter tool. It does not contain a live AI model/API.
- It does NOT automatically publish to YouTube, Instagram or Facebook. Actual auto-publishing needs official account authorization, platform/API permissions, and usually a scheduler/backend. A 100% free unlimited end-to-end AI video-generation + autopublishing service cannot be guaranteed.
- Thumbnail maker draws a simple branded graphic; it does not generate photorealistic images.
- Always check copyright, music/video rights, captions, dates, and platform rules before publishing.
- Never enter passwords, OTPs, payment details, or access tokens into this app.
